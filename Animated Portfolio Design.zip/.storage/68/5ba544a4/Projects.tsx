import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ExternalLink, 
  Users, 
  BarChart3, 
  Lightbulb,
  Target
} from 'lucide-react';
import resumeData from '@/data/resume.json';

const Projects = () => {
  const projectIcons = {
    'Academic/Personal': Users,
    'Technical': BarChart3
  };

  return (
    <section id="projects" className="py-20 bg-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-purple-500/10 text-purple-300 border-purple-500/20">
            Projects & Experience
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            My Experience Journey
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Practical experience and projects that showcase my skills and dedication
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {resumeData.projects_and_experience.map((project, index) => {
            const IconComponent = projectIcons[project.type as keyof typeof projectIcons] || Lightbulb;
            
            return (
              <Card key={index} className="p-8 bg-white/5 border-white/10 backdrop-blur-sm card-hover group">
                <div className="space-y-6">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-full group-hover:scale-110 transition-transform duration-300">
                        <IconComponent className="h-6 w-6 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-white group-hover:text-purple-300 transition-colors duration-300">
                          {project.title}
                        </h3>
                        <Badge variant="outline" className="mt-2 text-cyan-300 border-cyan-500/30">
                          {project.type}
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-300 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Technologies */}
                  {project.technologies && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-medium text-gray-400 uppercase tracking-wide">
                        Technologies Used
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech, techIndex) => (
                          <Badge
                            key={techIndex}
                            variant="secondary"
                            className="bg-purple-500/10 text-purple-300 border-purple-500/20 hover:bg-purple-500/20 transition-colors duration-300"
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Footer */}
                  <div className="pt-4 border-t border-white/10">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-gray-400">
                        <Target className="h-4 w-4" />
                        <span className="text-sm">Experience Project</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Call to Action */}
        <Card className="p-8 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-white/10 backdrop-blur-sm text-center">
          <div className="space-y-6">
            <div className="p-4 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-full w-20 h-20 mx-auto flex items-center justify-center">
              <Lightbulb className="h-10 w-10 text-purple-400" />
            </div>
            
            <div>
              <h3 className="text-2xl font-semibold text-white mb-4">
                Ready for New Challenges
              </h3>
              <p className="text-gray-300 max-w-2xl mx-auto mb-6">
                Eager to apply my skills and experience in a dynamic customer service role, 
                where I can make a meaningful impact and continue growing professionally.
              </p>
              
              <Button
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white px-8 py-3 text-lg font-medium glow transition-all duration-300"
                onClick={() => {
                  const contactSection = document.getElementById('contact');
                  if (contactSection) {
                    contactSection.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                Let's Connect
                <ExternalLink className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Projects;