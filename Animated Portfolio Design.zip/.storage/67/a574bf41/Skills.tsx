import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Code, 
  MessageSquare, 
  Tool, 
  Heart, 
  Lightbulb, 
  Users,
  Clock,
  Target
} from 'lucide-react';
import resumeData from '@/data/resume.json';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Software & Tools',
      icon: Code,
      skills: resumeData.technical_skills.software,
      color: 'from-purple-500 to-purple-600'
    },
    {
      title: 'Communication',
      icon: MessageSquare,
      skills: resumeData.technical_skills.communication,
      color: 'from-cyan-500 to-cyan-600'
    },
    {
      title: 'Digital Tools',
      icon: Tool,
      skills: resumeData.technical_skills.tools,
      color: 'from-indigo-500 to-indigo-600'
    }
  ];

  const softSkillsWithIcons = [
    { skill: 'Strong verbal and written communication skills', icon: MessageSquare, level: 95 },
    { skill: 'Problem-solving', icon: Lightbulb, level: 90 },
    { skill: 'Active listener with strong interpersonal skills', icon: Users, level: 95 },
    { skill: 'Quick learner', icon: Target, level: 92 },
    { skill: 'Ability to work under pressure', icon: Clock, level: 88 },
    { skill: 'Empathy', icon: Heart, level: 95 }
  ];

  return (
    <section id="skills" className="py-20 bg-gradient-to-b from-gray-900/50 to-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-purple-500/10 text-purple-300 border-purple-500/20">
            Skills & Expertise
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            What I Bring to the Table
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            A comprehensive skill set combining technical proficiency with strong interpersonal abilities
          </p>
        </div>

        {/* Technical Skills */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-white mb-8 text-center">Technical Skills</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => {
              const IconComponent = category.icon;
              return (
                <Card key={index} className="p-6 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className={`p-3 bg-gradient-to-r ${category.color}/20 rounded-full`}>
                      <IconComponent className="h-6 w-6 text-purple-400" />
                    </div>
                    <h4 className="text-xl font-semibold text-white">{category.title}</h4>
                  </div>
                  
                  <div className="space-y-3">
                    {category.skills.map((skill, skillIndex) => (
                      <div key={skillIndex} className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-cyan-400 rounded-full" />
                        <span className="text-gray-300 text-sm">{skill}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Soft Skills with Progress */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-white mb-8 text-center">Core Competencies</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {softSkillsWithIcons.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <Card key={index} className="p-6 bg-gradient-to-r from-purple-500/5 to-cyan-500/5 border-white/10 backdrop-blur-sm card-hover">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="p-2 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-lg">
                      <IconComponent className="h-5 w-5 text-purple-400" />
                    </div>
                    <h4 className="text-lg font-medium text-white flex-1">{item.skill}</h4>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-400">Proficiency</span>
                      <span className="text-sm text-purple-300 font-medium">{item.level}%</span>
                    </div>
                    <Progress value={item.level} className="h-2 bg-gray-800">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${item.level}%` }}
                      />
                    </Progress>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* All Soft Skills Grid */}
        <Card className="p-8 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-white/10 backdrop-blur-sm">
          <h3 className="text-2xl font-semibold text-white mb-6 text-center">Additional Strengths</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {resumeData.soft_skills.slice(6).map((skill, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-300"
              >
                <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-cyan-400 rounded-full" />
                <span className="text-gray-300 text-sm">{skill}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Skills;