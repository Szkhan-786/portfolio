import { Badge } from '@/components/ui/badge';
import { Heart, ArrowUp } from 'lucide-react';
import resumeData from '@/data/resume.json';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-black border-t border-white/10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="text-2xl font-bold gradient-text">MS</div>
              <div>
                <h3 className="text-lg font-semibold text-white">Mohd Shahnawaz</h3>
                <p className="text-gray-400 text-sm">Aspiring Customer Experience Executive</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm max-w-xs">
              Committed to delivering exceptional customer service and making a positive impact in every interaction.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white">Quick Links</h4>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Home', id: 'home' },
                { label: 'About', id: 'about' },
                { label: 'Education', id: 'education' },
                { label: 'Skills', id: 'skills' },
                { label: 'Projects', id: 'projects' },
                { label: 'Contact', id: 'contact' }
              ].map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    const element = document.getElementById(link.id);
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="text-gray-400 hover:text-purple-400 text-sm text-left transition-colors duration-300"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-white">Contact Info</h4>
            <div className="space-y-2">
              <p className="text-gray-400 text-sm">
                📧 {resumeData.personal_info.email}
              </p>
              <p className="text-gray-400 text-sm">
                📱 {resumeData.personal_info.phone}
              </p>
              <p className="text-gray-400 text-sm">
                📍 {resumeData.personal_info.location}, India
              </p>
            </div>
            
            <div className="pt-4">
              <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-500/30">
                Available for Opportunities
              </Badge>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-2 text-gray-400 text-sm">
              <span>Made with</span>
              <Heart className="h-4 w-4 text-red-400 animate-pulse" />
              <span>by Mohd Shahnawaz • {new Date().getFullYear()}</span>
            </div>

            <button
              onClick={scrollToTop}
              className="flex items-center space-x-2 text-gray-400 hover:text-purple-400 transition-colors duration-300 group"
            >
              <span className="text-sm">Back to top</span>
              <div className="p-2 bg-white/5 rounded-full group-hover:bg-purple-500/20 transition-colors duration-300">
                <ArrowUp className="h-4 w-4" />
              </div>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;