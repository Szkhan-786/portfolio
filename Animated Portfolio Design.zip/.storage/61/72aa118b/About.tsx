import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Target, Heart } from 'lucide-react';
import resumeData from '@/data/resume.json';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-black to-gray-900/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-purple-500/10 text-purple-300 border-purple-500/20">
            About Me
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            Get to Know Me
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Passionate about learning, growing, and making a positive impact through excellent customer service
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Profile Summary */}
          <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
            <div className="flex items-center space-x-4 mb-6">
              <div className="p-3 bg-purple-500/20 rounded-full">
                <User className="h-6 w-6 text-purple-400" />
              </div>
              <h3 className="text-2xl font-semibold text-white">Profile</h3>
            </div>
            <p className="text-gray-300 leading-relaxed">
              {resumeData.profile_summary}
            </p>
          </Card>

          {/* Personal Info */}
          <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
            <div className="flex items-center space-x-4 mb-6">
              <div className="p-3 bg-cyan-500/20 rounded-full">
                <Target className="h-6 w-6 text-cyan-400" />
              </div>
              <h3 className="text-2xl font-semibold text-white">Personal Details</h3>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Full Name</p>
                  <p className="font-medium text-white">{resumeData.personal_info.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Location</p>
                  <p className="font-medium text-white">{resumeData.personal_info.location}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Email</p>
                  <p className="font-medium text-white">{resumeData.personal_info.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Phone</p>
                  <p className="font-medium text-white">{resumeData.personal_info.phone}</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Key Strengths */}
        <Card className="p-8 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-white/10 backdrop-blur-sm">
          <div className="flex items-center space-x-4 mb-8">
            <div className="p-3 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-full">
              <Heart className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-2xl font-semibold text-white">Key Strengths</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {resumeData.soft_skills.slice(0, 6).map((skill, index) => (
              <div
                key={index}
                className="flex items-center space-x-3 p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-300"
              >
                <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-cyan-400 rounded-full" />
                <span className="text-gray-300 text-sm">{skill}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
};

export default About;