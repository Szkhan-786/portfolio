import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, Mail, Phone, MapPin } from 'lucide-react';
import resumeData from '@/data/resume.json';

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const scrollToAbout = () => {
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-black to-cyan-500/10" />
      
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-64 h-64 bg-purple-500/5 rounded-full animate-float" />
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-cyan-500/5 rounded-full animate-float delay-500" />
        <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-purple-400/3 rounded-full animate-float delay-300" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-8">
          {/* Main content */}
          <div className={`space-y-6 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
            <div className="space-y-2">
              <Badge variant="secondary" className="mb-4 bg-purple-500/10 text-purple-300 border-purple-500/20">
                Welcome to my portfolio
              </Badge>
              <h1 className="text-5xl md:text-7xl font-bold tracking-tight">
                <span className="gradient-text">Mohd Shahnawaz</span>
              </h1>
              <div className="text-xl md:text-2xl text-gray-300 font-medium">
                B.Pharm Student & Aspiring Customer Experience Executive
              </div>
            </div>

            <p className={`text-lg md:text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed ${isVisible ? 'animate-fade-in-up delay-200' : 'opacity-0'}`}>
              {resumeData.profile_summary}
            </p>
          </div>

          {/* Contact info cards */}
          <div className={`grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto ${isVisible ? 'animate-fade-in-up delay-300' : 'opacity-0'}`}>
            <Card className="p-4 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-purple-400" />
                <div className="text-left">
                  <p className="text-sm text-gray-400">Email</p>
                  <p className="text-sm font-medium">{resumeData.personal_info.email}</p>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-purple-400" />
                <div className="text-left">
                  <p className="text-sm text-gray-400">Phone</p>
                  <p className="text-sm font-medium">{resumeData.personal_info.phone}</p>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-purple-400" />
                <div className="text-left">
                  <p className="text-sm text-gray-400">Location</p>
                  <p className="text-sm font-medium">{resumeData.personal_info.location}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* CTA Button */}
          <div className={`${isVisible ? 'animate-fade-in-up delay-400' : 'opacity-0'}`}>
            <Button
              onClick={scrollToAbout}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white px-8 py-3 text-lg font-medium glow transition-all duration-300"
            >
              Explore My Journey
            </Button>
          </div>

          {/* Scroll indicator */}
          <div className={`absolute bottom-8 left-1/2 transform -translate-x-1/2 ${isVisible ? 'animate-fade-in delay-500' : 'opacity-0'}`}>
            <button
              onClick={scrollToAbout}
              className="text-gray-400 hover:text-white transition-colors duration-300 animate-bounce"
            >
              <ChevronDown className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;