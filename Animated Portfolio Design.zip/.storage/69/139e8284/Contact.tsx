import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Send,
  User,
  MessageSquare,
  Clock,
  CheckCircle
} from 'lucide-react';
import resumeData from '@/data/resume.json';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    
    // Reset form after success
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
    }, 3000);
  };

  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: resumeData.personal_info.email,
      href: `mailto:${resumeData.personal_info.email}`,
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: Phone,
      label: 'Phone',
      value: resumeData.personal_info.phone,
      href: `tel:${resumeData.personal_info.phone}`,
      color: 'from-cyan-500 to-cyan-600'
    },
    {
      icon: MapPin,
      label: 'Location',
      value: resumeData.personal_info.address,
      href: `https://maps.google.com/?q=${encodeURIComponent(resumeData.personal_info.address)}`,
      color: 'from-indigo-500 to-indigo-600'
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-black to-gray-900/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-purple-500/10 text-purple-300 border-purple-500/20">
            Get In Touch
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            Let's Start a Conversation
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Ready to contribute to your team's success. Reach out to discuss opportunities or just to connect!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-semibold text-white mb-6">Contact Information</h3>
              <div className="space-y-4">
                {contactInfo.map((contact, index) => {
                  const IconComponent = contact.icon;
                  return (
                    <Card key={index} className="p-6 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
                      <a
                        href={contact.href}
                        target={contact.label === 'Location' ? '_blank' : undefined}
                        rel={contact.label === 'Location' ? 'noopener noreferrer' : undefined}
                        className="flex items-center space-x-4 hover:text-purple-300 transition-colors duration-300"
                      >
                        <div className={`p-3 bg-gradient-to-r ${contact.color}/20 rounded-full`}>
                          <IconComponent className="h-6 w-6 text-purple-400" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-400 uppercase tracking-wide">
                            {contact.label}
                          </p>
                          <p className="text-white font-medium">
                            {contact.value}
                          </p>
                        </div>
                      </a>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Availability */}
            <Card className="p-6 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border-white/10 backdrop-blur-sm">
              <div className="flex items-center space-x-4 mb-4">
                <div className="p-3 bg-gradient-to-r from-green-500/20 to-green-600/20 rounded-full">
                  <Clock className="h-6 w-6 text-green-400" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white">Availability</h4>
                  <p className="text-gray-400">Ready to start immediately</p>
                </div>
              </div>
              <p className="text-gray-300">
                Currently seeking opportunities in customer service and support roles. 
                Open to full-time positions and eager to contribute to team success.
              </p>
            </Card>
          </div>

          {/* Contact Form */}
          <div>
            <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm">
              <h3 className="text-2xl font-semibold text-white mb-6">Send a Message</h3>
              
              {isSubmitted ? (
                <div className="text-center py-8">
                  <div className="p-4 bg-green-500/20 rounded-full w-20 h-20 mx-auto flex items-center justify-center mb-4">
                    <CheckCircle className="h-10 w-10 text-green-400" />
                  </div>
                  <h4 className="text-xl font-semibold text-white mb-2">Message Sent!</h4>
                  <p className="text-gray-400">Thank you for reaching out. I'll get back to you soon!</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium text-gray-300">
                        Full Name
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          placeholder="Enter your name"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-400 focus:border-purple-500"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium text-gray-300">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="Enter your email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-400 focus:border-purple-500"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="subject" className="text-sm font-medium text-gray-300">
                      Subject
                    </label>
                    <div className="relative">
                      <MessageSquare className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="subject"
                        name="subject"
                        type="text"
                        placeholder="What's this about?"
                        value={formData.subject}
                        onChange={handleInputChange}
                        className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-400 focus:border-purple-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium text-gray-300">
                      Message
                    </label>
                    <Textarea
                      id="message"
                      name="message"
                      placeholder="Tell me about your project or opportunity..."
                      rows={5}
                      value={formData.message}
                      onChange={handleInputChange}
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-400 focus:border-purple-500 resize-none"
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white font-medium glow transition-all duration-300 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Sending...
                      </>
                    ) : (
                      <>
                        Send Message
                        <Send className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </form>
              )}
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;