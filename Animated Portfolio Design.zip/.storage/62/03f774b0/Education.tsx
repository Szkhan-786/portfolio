import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GraduationCap, Calendar, MapPin, Award } from 'lucide-react';
import resumeData from '@/data/resume.json';

const Education = () => {
  return (
    <section id="education" className="py-20 bg-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4 bg-purple-500/10 text-purple-300 border-purple-500/20">
            Education
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            Academic Journey
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Building a strong foundation through continuous learning and academic excellence
          </p>
        </div>

        {/* Education Timeline */}
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 to-cyan-500 transform md:-translate-x-0.5" />

          <div className="space-y-8">
            {resumeData.education.map((edu, index) => (
              <div
                key={index}
                className={`relative flex items-center ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full transform md:-translate-x-2 z-10" />

                {/* Content */}
                <div className={`ml-12 md:ml-0 w-full md:w-5/12 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
                  <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm card-hover">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-purple-500/20 rounded-lg">
                            <GraduationCap className="h-5 w-5 text-purple-400" />
                          </div>
                          <div>
                            <Badge
                              variant={edu.status === 'Current' ? 'default' : 'secondary'}
                              className={edu.status === 'Current' 
                                ? 'bg-green-500/20 text-green-300 border-green-500/30' 
                                : 'bg-gray-500/20 text-gray-300 border-gray-500/30'
                              }
                            >
                              {edu.status}
                            </Badge>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-xl font-semibold text-white mb-2">
                          {edu.degree}
                        </h3>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2 text-gray-400">
                            <MapPin className="h-4 w-4" />
                            <span>{edu.institution}</span>
                          </div>
                          <div className="flex items-center space-x-2 text-gray-400">
                            <Calendar className="h-4 w-4" />
                            <span>{edu.duration}</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2">
                        <Badge variant="outline" className="text-purple-300 border-purple-500/30">
                          {edu.type}
                        </Badge>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Spacer for timeline */}
                <div className="hidden md:block w-2/12" />
              </div>
            ))}
          </div>
        </div>

        {/* Certifications */}
        {resumeData.certifications && resumeData.certifications.length > 0 && (
          <div className="mt-16">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold text-white mb-4">Certifications</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {resumeData.certifications.map((cert, index) => (
                <Card key={index} className="p-6 bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border-white/10 backdrop-blur-sm card-hover">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="p-3 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-full">
                      <Award className="h-6 w-6 text-purple-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-white">{cert.name}</h4>
                      <p className="text-gray-400">{cert.year}</p>
                    </div>
                  </div>
                  <Badge
                    variant="secondary"
                    className={cert.status === 'Completed' 
                      ? 'bg-green-500/20 text-green-300 border-green-500/30' 
                      : 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
                    }
                  >
                    {cert.status}
                  </Badge>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Education;